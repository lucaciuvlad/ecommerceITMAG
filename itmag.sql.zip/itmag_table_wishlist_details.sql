
-- --------------------------------------------------------

--
-- Table structure for table `wishlist_details`
--

CREATE TABLE `wishlist_details` (
  `wishlist_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
