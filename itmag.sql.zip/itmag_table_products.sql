
-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_metaphone` varchar(100) NOT NULL,
  `product_price` decimal(7,2) NOT NULL,
  `product_old_price` decimal(7,2) DEFAULT NULL,
  `product_created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `brand_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `product_stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `product_metaphone`, `product_price`, `product_old_price`, `product_created_at`, `brand_id`, `category_id`, `product_stock`) VALUES
(45, 'Telefon mobil Samsung Galaxy S21, Dual SIM, 128GB, 8GB RAM, 5G, Phantom Pink', 'TLFNMBLSMSNKKLKSSTLSMKBKBRMKFNTMPNK', '3299.99', '4099.99', '2021-05-13 19:47:59', 1, 3, 15),
(46, 'Telefon mobil Samsung Galaxy S21 Plus, Dual SIM, 128GB, 8GB RAM, 5G, Phantom Black', 'TLFNMBLSMSNKKLKSSPLSTLSMKBKBRMKFNTMBLK', '3799.99', '5099.99', '2021-05-13 19:48:54', 1, 3, 20),
(47, 'Telefon mobil Samsung Galaxy S20 FE, Dual SIM, 128GB, 6GB RAM, 5G, Cloud Orange', 'TLFNMBLSMSNKKLKSSFTLSMKBKBRMKKLTRNJ', '2799.99', '3599.99', '2021-05-13 19:50:04', 1, 3, 25),
(48, 'Telefon mobil Huawei P40 Lite E, Dual SIM, 64GB, 4G, Aurora Blue', 'TLFNMBLHWPLTTLSMKBKRRBL', '723.60', '840.00', '2021-05-13 20:08:42', 2, 3, 15);
