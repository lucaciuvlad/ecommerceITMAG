
-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_metaphone` varchar(100) NOT NULL,
  `product_price` decimal(7,2) NOT NULL,
  `product_old_price` decimal(7,2) DEFAULT NULL,
  `product_created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `brand_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `product_stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `product_metaphone`, `product_price`, `product_old_price`, `product_created_at`, `brand_id`, `category_id`, `product_stock`) VALUES
(45, '  Telefon mobil Samsung Galaxy S21, Dual SIM, 128GB, 8GB RAM, 5G, Phantom Pink', 'TLFNMBLSMSNKKLKSSTLSMKBKBRMKFNTMPNK', '3299.99', '4099.99', '2021-05-13 19:47:59', 1, 3, 15),
(46, 'Telefon mobil Samsung Galaxy S21 Plus, Dual SIM, 128GB, 8GB RAM, 5G, Phantom Black', 'TLFNMBLSMSNKKLKSSPLSTLSMKBKBRMKFNTMBLK', '3799.99', '5099.99', '2021-05-13 19:48:54', 1, 3, 20),
(47, 'Telefon mobil Samsung Galaxy S20 FE, Dual SIM, 128GB, 6GB RAM, 5G, Cloud Orange', 'TLFNMBLSMSNKKLKSSFTLSMKBKBRMKKLTRNJ', '2799.99', '3599.99', '2021-05-13 19:50:04', 1, 3, 25),
(48, 'Telefon mobil Huawei P40 Lite E, Dual SIM, 64GB, 4G, Aurora Blue', 'TLFNMBLHWPLTTLSMKBKRRBL', '723.60', '840.00', '2021-05-13 20:08:42', 2, 3, 15),
(49, 'Telefon mobil Samsung Galaxy A21s, Dual SIM, 32GB, 4G, Prism Crush White', 'TLFNMBLSMSNKKLKSSTLSMKBKPRSMKRXHT', '740.18', '1011.50', '2021-05-17 12:57:55', 1, 3, 15),
(51, 'Telefon mobil Samsung Galaxy A20e, Dual SIM, 32GB, 4G, Black', 'TLFNMBLSMSNKKLKSTLSMKBKBLK', '674.73', '773.50', '2021-05-17 14:51:58', 1, 3, 2),
(52, 'Telefon mobil Samsung Galaxy A71, Dual SIM, 128GB, 6GB RAM, 4G, Blue', 'TLFNMBLSMSNKKLKSTLSMKBKBRMKBL', '1739.78', '2142.00', '2021-05-17 16:03:13', 1, 3, 7),
(53, 'Telefon mobil Samsung Galaxy A51, Dual SIM, 128GB, 4GB RAM, 4G, Prism Black', 'TLFNMBLSMSNKKLKSTLSMKBKBRMKPRSMBLK', '1409.99', '1799.99', '2021-05-17 16:06:42', 1, 3, 8),
(54, '  Telefon mobil Samsung Galaxy S21 Ultra, Dual SIM, 128GB, 12GB RAM, 5G, Phantom Black', 'TLFNMBLSMSNKKLKSSLTRTLSMKBKBRMKFNTMBLK', '5469.00', '5500.00', '2021-05-17 16:54:23', 1, 3, 30),
(55, ' Telefon mobil Samsung Galaxy S10+, Dual SIM, 128GB, 8GB RAM, 4G, Prism White', 'TLFNMBLSMSNKKLKSSTLSMKBKBRMKPRSMHT', '3389.00', '3549.00', '2021-05-17 17:17:03', 1, 3, 10),
(56, 'Telefon mobil Samsung Galaxy A52, Dual SIM, 128GB, 6GB RAM, 5G, Black', 'TLFNMBLSMSNKKLKSTLSMKBKBRMKBLK', '1799.99', '2099.99', '2021-05-17 17:24:56', 1, 3, 7),
(57, 'Telefon mobil Huawei P Smart (2021), Dual SIM, 128GB, 4G, Crush Green', 'TLFNMBLHWPSMRTTLSMKBKKRXKRN', '719.00', '1149.99', '2021-05-17 17:30:51', 2, 3, 15),
(58, 'Telefon mobil Huawei P Smart (2021), Dual SIM, 128GB, 4G, Midnight Black', 'TLFNMBLHWPSMRTTLSMKBKMTNTBLK', '699.99', '1299.99', '2021-05-17 17:40:24', 2, 3, 12),
(59, 'Telefon mobil Huawei P40 Lite, Dual SIM, 128GB, 6GB RAM, 4G, Sakura Pink', 'TLFNMBLHWPLTTLSMKBKBRMKSKRPNK', '925.00', '1550.00', '2021-05-17 17:42:07', 2, 3, 9),
(60, 'Telefon mobil Huawei P40 Pro, Dual SIM, 256GB, 8GB RAM, 5G, Silver Frost', 'TLFNMBLHWPPRTLSMKBKBRMKSLFRFRST', '3209.99', '4599.99', '2021-05-17 17:45:07', 2, 3, 52),
(61, 'Telefon mobil Huawei P30 Lite, Dual SIM, 128GB, 4G, Peacock Blue', 'TLFNMBLHWPLTTLSMKBKPKKBL', '3299.99', NULL, '2021-05-17 17:47:20', 2, 3, 75),
(62, 'Telefon mobil Huawei Nova 5T, Dual SIM, 128GB, 6GB RAM, 4G, Midsummer Purple', 'TLFNMBLHWNFTTLSMKBKBRMKMTSMRPRPL', '1549.00', NULL, '2021-05-17 17:50:26', 2, 3, 45),
(63, 'Telefon mobil Huawei Y6P, Dual SIM, 64GB, 4G, Emerald Green', 'TLFNMBLHWPTLSMKBKMRLTKRN', '679.00', '899.00', '2021-05-17 21:14:31', 2, 3, 15),
(64, 'Telefon mobil Huawei P30 Pro, Dual SIM, 128GB, 6GB RAM, 4G, Breathing Crystal', 'TLFNMBLHWPPRTLSMKBKBRMKBR0NKKRSTL', '3199.00', NULL, '2021-05-17 21:16:07', 2, 3, 9),
(65, '  Telefon mobil Huawei Mate XS, Dual SIM, 512GB, 8GB RAM, 5G, Interstellar Blue', 'TLFNMBLHWMTKSSTLSMKBKBRMKNTRSTLRBL', '7399.00', '10999.00', '2021-05-17 21:17:54', 1, 3, 20);
