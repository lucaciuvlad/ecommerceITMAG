
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_active_account` tinyint(4) NOT NULL DEFAULT 0,
  `user_registered_at` datetime NOT NULL DEFAULT current_timestamp(),
  `user_first_name` varchar(100) NOT NULL,
  `user_last_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_email`, `user_password`, `user_active_account`, `user_registered_at`, `user_first_name`, `user_last_name`) VALUES
(9, 'vladlucaciu0@yahoo.com', '$2y$10$ApCT86aG1lSrvaAQP99FgejphfEMshAAVnVjavleRj77yeJgD7yYi', 1, '2021-06-11 23:02:52', 'Lucaciu', 'Vlad');
