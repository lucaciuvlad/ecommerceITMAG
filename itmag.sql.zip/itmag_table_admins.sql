
-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `admin_first_name` varchar(100) NOT NULL,
  `admin_last_name` varchar(100) NOT NULL,
  `admin_active_account` tinyint(4) NOT NULL DEFAULT 0,
  `admin_registered_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `admin_email`, `admin_password`, `admin_first_name`, `admin_last_name`, `admin_active_account`, `admin_registered_at`) VALUES
(24, 'lucaciu_vlad@yahoo.com', '$2y$10$.VS9.eSyfR8hri1sptHKQORZgYf.O5d5rWdT8FvcHDRqiLQOgR462', 'Lucaciu', 'Vlad', 1, '2021-05-12 19:26:45'),
(26, 'test', 'test', 'test', 'test', 1, '2021-05-14 16:50:24');
