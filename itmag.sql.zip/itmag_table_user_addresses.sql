
-- --------------------------------------------------------

--
-- Table structure for table `user_addresses`
--

CREATE TABLE `user_addresses` (
  `id` int(11) NOT NULL,
  `user_full_address` text NOT NULL,
  `user_phone_number` varchar(20) NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_addresses`
--

INSERT INTO `user_addresses` (`id`, `user_full_address`, `user_phone_number`, `user_id`) VALUES
(6, 'Strada Crinului, Nr.3, Ap.9, Cluj-Napoca, Cluj', '0728370370', 9);
