
-- --------------------------------------------------------

--
-- Table structure for table `product_descriptions`
--

CREATE TABLE `product_descriptions` (
  `id` int(11) NOT NULL,
  `product_description_title` varchar(50) NOT NULL,
  `product_description_body` text NOT NULL,
  `product_description_image` varchar(100) DEFAULT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_descriptions`
--

INSERT INTO `product_descriptions` (`id`, `product_description_title`, `product_description_body`, `product_description_image`, `product_id`) VALUES
(1, 'Tot ce vrei, pentru a face tot ce iti place', 'Acesta este un telefonul pentru cei care isi doresc totul. V-am ascultat pe voi, fanii, iar ceea ce am creat este un telefon care nu accepta niciun compromis. Acesta este telefonul creat special pentru fanii de toate tipurile. Asa ca, indiferent daca esti fan al fotografiei, al jocurilor sau al transmiterii in feed-ul tau a tot ceea ce te inspira, iti oferim un telefon care contine tot ce poate fi mai bun in materie de inovatie din gama S20. Acesta este telefonul care iti ofera tot ce vrei, pentru a face cat mai mult din ceea ce iti place.', 'galaxy-s20-fe-cloud-orange-desc-1.png', 47),
(2, 'Nuante care vor starni gelozia curcubeului', 'elefonul nu iti paraseste mana aproape niciodata, asa ca trebuie sa se asorteze perfect stilului tau. Alege dintr-o gama larga de nuante in trend, cu un finisaj mat elegant, de la spectaculos si indraznet la subtil si clasic.', 'galaxy-s20-fe-cloud-orange-desc-2.png', 47),
(5, 'Toate privirile sunt indreptate spre ecranul Infin', 'Upgradeaza ceea ce vezi. Ecranul de 6.5\" Full HD Infinity-O Display are trei laturi abia vizibile ce inconjoara marginile plate si un foarte mic orificiu pentru camera. Asta inseamna un ecran mai captivant, care face gaming-ul, streaming-ul si apelurile video mult mai distractive.', 'galaxy-s20-fe-cloud-orange-desc-3.png', 47),
(6, 'Camera cu trei obiective, de tip profesional', 'Cele trei camere de pe partea din spate iti permit sa obtii cu usurinta acea fotografie profesionala, care nu are nevoie de filtre. Incadreaza scena cu camera Wide-Angle, apoi largeste imaginea mai mult cu camera Ultra Wide sau apropie imaginea folosind zoom-ul optic 3x al camerei Telephoto.', 'galaxy-s20-fe-cloud-orange-desc-4.png', 47),
(8, 'Stralucitor si protejat in toate modurile', 'Uimitor de luminos. Incredibil de realist. Surprinzator de fin - acest afisaj surprinde prin culori vibrante si o claritate uimitoare, oferind o experienta de vizionare de neegalat. Si asta chiar si in lumina puternica a soarelui. Urmatorul tau maraton de filme tocmai a devenit mai confortabil. Telefonul reduce in mod semnificativ presiunea si disconfortul resimtite la nivelul ochilor, astfel incat sa poti viziona confortabil emisiunile tale preferate dimineata, la pranz si noaptea.', 'galaxy-s21-phantom-pink-desc-2.png', 45),
(9, 'Creat pentru a descoperi epicul din fiecare zi', 'Nu vei mai rata niciodata fotografia perfecta. Conceput pentru a revolutiona filmarea si fotografierea cu o rezolutie cinematografica de peste 8K, astfel incat sa poti face fotografii epice chiar dintr-un clip video. 64MP, cel mai rapid cip al nostru si o baterie solida cu autonomie pentru intreaga zi. Lucrurile tocmai au luat o turnura epica.', 'galaxy-s21-phantom-pink-desc-1.png', 45);
