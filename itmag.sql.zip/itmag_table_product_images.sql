
-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` int(11) NOT NULL,
  `product_image` varchar(100) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_image`, `product_id`) VALUES
(256, 's21-phantom-pink-2.png', 45),
(257, 's21-phantom-pink-1.png', 45),
(258, 's21-phantom-pink-3.png', 45),
(259, 's21-phantom-pink-4.png', 45),
(260, 'telefon-mobil-samsung-galaxy-s21-phantom-black-2.png', 46),
(261, 'telefon-mobil-samsung-galaxy-s21-phantom-black-4.png', 46),
(262, 'telefon-mobil-samsung-galaxy-s21-phantom-black-1.png', 46),
(263, 'telefon-mobil-samsung-galaxy-s21-phantom-black-3.png', 46),
(264, 's21-cloud-orange-3.png', 47),
(265, 's21-cloud-orange-1.png', 47),
(266, 's21-cloud-orange-2.png', 47),
(267, 's21-cloud-orange-4.png', 47);
